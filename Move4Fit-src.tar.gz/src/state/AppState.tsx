import AsyncStorage from '@react-native-async-storage/async-storage';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

import { applySessionResult, type ProgressionResult } from '@/src/domain/progression';
import type {
  ChildProfile,
  Feedback,
  FunctionalAssessment,
  ProgressMap,
  SessionLog,
  TrackingResult,
  WorkoutPlan,
} from '@/src/domain/types';

/**
 * Состояние приложения. Пока хранится локально на устройстве (AsyncStorage).
 * Следующий шаг — синхронизация с сервером (см. README, раздел «Бэкенд»),
 * чтобы куратор видел прогресс и данные не терялись при смене телефона.
 */
export interface User {
  name: string;
  email: string;
}

interface PersistedState {
  user?: User;
  child?: ChildProfile;
  assessment?: FunctionalAssessment;
  progress: ProgressMap;
  sessions: SessionLog[];
  trackingResults: TrackingResult[];
}

const EMPTY: PersistedState = { progress: {}, sessions: [], trackingResults: [] };
const STORAGE_KEY = 'move4fit/state/v1';

const newId = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

interface AppStateValue extends PersistedState {
  ready: boolean;
  signUp(user: User): void;
  saveChild(child: Omit<ChildProfile, 'id' | 'createdAt' | 'doctorClearanceConfirmed'>): ChildProfile;
  saveAssessment(a: FunctionalAssessment): void;
  confirmDoctorClearance(): void;
  completeSession(plan: WorkoutPlan, feedback: Feedback, pain: boolean, note?: string): ProgressionResult;
  addTrackingResult(testId: string, value: number): void;
  resetAll(): void;
}

const Ctx = createContext<AppStateValue | null>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistedState>(EMPTY);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => raw && setState({ ...EMPTY, ...JSON.parse(raw) }))
      .catch(() => {})
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    if (ready) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => {});
  }, [state, ready]);

  const signUp = useCallback((user: User) => setState((s) => ({ ...s, user })), []);

  const saveChild = useCallback<AppStateValue['saveChild']>((data) => {
    const child: ChildProfile = {
      ...data,
      id: newId(),
      createdAt: new Date().toISOString(),
      doctorClearanceConfirmed: false,
    };
    setState((s) => ({ ...s, child, assessment: undefined }));
    return child;
  }, []);

  const saveAssessment = useCallback((assessment: FunctionalAssessment) => setState((s) => ({ ...s, assessment })), []);

  const confirmDoctorClearance = useCallback(
    () => setState((s) => (s.child ? { ...s, child: { ...s.child, doctorClearanceConfirmed: true } } : s)),
    [],
  );

  const completeSession = useCallback<AppStateValue['completeSession']>(
    (plan, feedback, pain, note) => {
      const result = applySessionResult(state.progress, plan.items, feedback, pain);
      const log: SessionLog = {
        id: newId(),
        childId: state.child?.id ?? '',
        date: new Date().toISOString(),
        items: plan.items,
        feedback,
        pain,
        note,
      };
      setState((s) => ({ ...s, progress: result.progress, sessions: [...s.sessions, log] }));
      return result;
    },
    [state.progress, state.child],
  );

  const addTrackingResult = useCallback(
    (testId: string, value: number) =>
      setState((s) => ({
        ...s,
        trackingResults: [
          ...s.trackingResults,
          { id: newId(), childId: s.child?.id ?? '', testId, value, date: new Date().toISOString() },
        ],
      })),
    [],
  );

  const resetAll = useCallback(() => setState(EMPTY), []);

  const value = useMemo<AppStateValue>(
    () => ({
      ...state,
      ready,
      signUp,
      saveChild,
      saveAssessment,
      confirmDoctorClearance,
      completeSession,
      addTrackingResult,
      resetAll,
    }),
    [state, ready, signUp, saveChild, saveAssessment, confirmDoctorClearance, completeSession, addTrackingResult, resetAll],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppStateValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp must be used inside AppStateProvider');
  return v;
}
