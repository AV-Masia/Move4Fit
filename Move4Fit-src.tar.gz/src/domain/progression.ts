import type { Difficulty, Feedback, PlannedExercise, ProgressMap } from './types';

/** Сколько «легко» подряд нужно, чтобы усложнить упражнение. */
export const EASY_STREAK_TO_ADVANCE = 2;

const clamp = (d: number): Difficulty => Math.min(3, Math.max(1, d)) as Difficulty;

export interface ProgressionResult {
  progress: ProgressMap;
  /** Показать родителю совет сделать паузу и написать куратору. */
  contactCurator: boolean;
  /** Все упражнения на максимальной сложности и даются легко — пора пройти анкету заново. */
  suggestReassessment: boolean;
}

/**
 * Правила прогрессии (⚠️ черновик, согласовать со специалистом):
 *  • боль → снижаем сложность всех упражнений занятия и советуем связаться с куратором;
 *  • «тяжело» → снижаем сложность на 1;
 *  • «нормально» → оставляем, серия «легко» сбрасывается;
 *  • «легко» N раз подряд → повышаем сложность на 1.
 */
export function applySessionResult(
  progress: ProgressMap,
  items: PlannedExercise[],
  feedback: Feedback,
  pain: boolean,
): ProgressionResult {
  const next: ProgressMap = { ...progress };
  for (const item of items) {
    const cur = next[item.exerciseId] ?? { difficulty: item.difficulty, easyStreak: 0 };
    if (pain || feedback === 'hard') {
      next[item.exerciseId] = { difficulty: clamp(cur.difficulty - 1), easyStreak: 0 };
    } else if (feedback === 'ok') {
      next[item.exerciseId] = { difficulty: cur.difficulty, easyStreak: 0 };
    } else {
      const streak = cur.easyStreak + 1;
      next[item.exerciseId] =
        streak >= EASY_STREAK_TO_ADVANCE && cur.difficulty < 3
          ? { difficulty: clamp(cur.difficulty + 1), easyStreak: 0 }
          : { difficulty: cur.difficulty, easyStreak: streak };
    }
  }
  const suggestReassessment =
    !pain &&
    feedback === 'easy' &&
    items.length > 0 &&
    items.every((i) => (progress[i.exerciseId]?.difficulty ?? 1) === 3);
  return { progress: next, contactCurator: pain, suggestReassessment };
}
