/**
 * Модель данных Move4Fit.
 *
 * Цепочка алгоритма:
 * возраст → диагноз → противопоказания/особенности → функциональный уровень →
 * конкретные возможности → подходящие упражнения → уровень сложности → прогрессия.
 */

// ---------- Ребёнок ----------

export type Diagnosis =
  | 'cerebral_palsy' // ДЦП
  | 'down_syndrome' // синдром Дауна
  | 'autism_spectrum' // РАС
  | 'developmental_delay' // задержка моторного развития
  | 'spina_bifida' // спинномозговая грыжа
  | 'other';

export interface ChildProfile {
  id: string;
  name: string;
  ageYears: number;
  diagnosis: Diagnosis;
  /** Свободный комментарий родителя (форма ДЦП, сопутствующие состояния и т.п.) */
  diagnosisNote?: string;
  /** Родитель подтвердил, что врач разрешил занятия (нужно при «блокирующих» особенностях). */
  doctorClearanceConfirmed: boolean;
  createdAt: string; // ISO
}

// ---------- Функциональный профиль ----------

/**
 * Внутренний уровень, близкий к GMFCS I–V. Родителю этот термин не показывается —
 * он видит описание простыми словами.
 */
export type FunctionalLevel = 1 | 2 | 3 | 4 | 5;

/** Конкретные двигательные возможности ребёнка, которые выясняются вопросами. */
export type Capability =
  | 'head_control' // держит голову
  | 'sit_with_support' // сидит с поддержкой
  | 'sit_independent' // сидит сам, без опоры на руки
  | 'stand_with_support' // стоит у опоры
  | 'stand_independent' // стоит без опоры
  | 'walk_with_device' // ходит с ходунками/тростями
  | 'walk_independent' // ходит сам в помещении
  | 'walk_outdoors' // ходит сам на улице, по неровной поверхности
  | 'stairs_with_rail' // поднимается по лестнице с перилами
  | 'stairs_no_rail' // поднимается по лестнице без перил
  | 'run_jump'; // бегает, прыгает

/** Особенности здоровья, которые меняют набор упражнений или требуют разрешения врача. */
export type SafetyFlag =
  | 'uncontrolled_seizures' // неконтролируемые судороги/эпилепсия
  | 'recent_surgery' // операция за последние 6 месяцев
  | 'recent_botulinum' // ботулинотерапия за последний месяц
  | 'hip_instability' // подвывих/вывих тазобедренного сустава
  | 'shunt' // шунт
  | 'fragile_bones' // хрупкость костей, переломы в анамнезе
  | 'heart_condition'; // заболевание сердца

export interface FunctionalAssessment {
  childId: string;
  date: string; // ISO
  answers: Record<string, boolean>;
  capabilities: Capability[];
  level: FunctionalLevel;
  safetyFlags: SafetyFlag[];
  /** Какие риски упражнений исключены (из диагноза и особенностей). */
  excludedRisks: ExerciseRisk[];
  /** Нужно разрешение врача, прежде чем показывать тренировки. */
  clearanceRequired: boolean;
}

// ---------- Упражнения ----------

export type Position = 'lying' | 'sitting' | 'kneeling' | 'standing';
export type Goal = 'strength' | 'balance' | 'flexibility' | 'coordination' | 'endurance';
export type WorkoutPart = 'warmup' | 'main' | 'cooldown';

/** Характеристики упражнения, которые могут быть противопоказаны. */
export type ExerciseRisk =
  | 'impact' // прыжки, удары
  | 'hip_loading' // нагрузка на тазобедренный сустав в крайних положениях
  | 'head_down' // положение вниз головой
  | 'neck_flexion' // сильное сгибание шеи (кувырки)
  | 'breath_holding' // натуживание
  | 'high_intensity'; // высокая интенсивность

export type Difficulty = 1 | 2 | 3;

export interface ExerciseVariant {
  difficulty: Difficulty;
  instructions: string;
  sets: number;
  reps?: number;
  durationSec?: number;
}

export interface Exercise {
  id: string;
  title: string;
  description: string;
  part: WorkoutPart;
  goals: Goal[];
  position: Position;
  /** Все перечисленные возможности должны быть у ребёнка. */
  requires: Capability[];
  /** Для каких функциональных уровней подходит. */
  levels: FunctionalLevel[];
  minAge: number;
  risks: ExerciseRisk[];
  variants: ExerciseVariant[];
  /** Ссылка на видео (собственная съёмка проекта). */
  videoUrl?: string;
  equipment?: string[];
}

// ---------- Занятия и прогрессия ----------

export type Feedback = 'easy' | 'ok' | 'hard';

export interface PlannedExercise {
  exerciseId: string;
  difficulty: Difficulty;
}

export interface WorkoutPlan {
  date: string; // ISO day
  items: PlannedExercise[];
}

export interface SessionLog {
  id: string;
  childId: string;
  date: string; // ISO
  items: PlannedExercise[];
  feedback: Feedback;
  pain: boolean;
  note?: string;
}

export interface ExerciseProgress {
  difficulty: Difficulty;
  /** Сколько занятий подряд упражнение было «легко». */
  easyStreak: number;
}

export type ProgressMap = Record<string, ExerciseProgress>;

// ---------- Тесты динамики ----------

export interface TrackingTest {
  id: string;
  title: string;
  instructions: string;
  unit: string;
  levels: FunctionalLevel[];
  requires: Capability[];
  higherIsBetter: boolean;
}

export interface TrackingResult {
  id: string;
  childId: string;
  testId: string;
  date: string;
  value: number;
}
