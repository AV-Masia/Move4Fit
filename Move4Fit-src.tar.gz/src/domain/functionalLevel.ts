import {
  CLEARANCE_FLAGS,
  DIAGNOSIS_EXCLUSIONS,
  FLAG_EXCLUSIONS,
  MOTOR_QUESTIONS,
  SAFETY_QUESTIONS,
  isQuestionVisible,
} from './questionnaire';
import type {
  Capability,
  ChildProfile,
  ExerciseRisk,
  FunctionalAssessment,
  FunctionalLevel,
  SafetyFlag,
} from './types';

export function capabilitiesFromAnswers(answers: Record<string, boolean>): Capability[] {
  return MOTOR_QUESTIONS.filter((q) => isQuestionVisible(q, answers) && answers[q.id] === true).map(
    (q) => q.capability,
  );
}

/**
 * Определение внутреннего функционального уровня (по мотивам GMFCS).
 *
 * ⚠️ ЧЕРНОВИК — упрощённые правила, требуют проверки реабилитологом.
 * GMFCS описывает уровни по возрастным группам (<2, 2–4, 4–6, 6–12, 12–18 лет);
 * здесь используется упрощение, а для детей младше 4 лет снижаются требования к уровню 1.
 */
export function determineLevel(caps: Capability[], ageYears: number): FunctionalLevel {
  const has = (c: Capability) => caps.includes(c);

  if (has('walk_independent')) {
    const level1 =
      ageYears < 4
        ? true // в раннем возрасте самостоятельная ходьба уже соответствует уровню I
        : has('walk_outdoors') && has('stairs_no_rail') && has('run_jump');
    return level1 ? 1 : 2;
  }
  if (has('walk_with_device')) return 3;
  if (has('sit_independent') || (has('head_control') && has('sit_with_support'))) return 4;
  return 5;
}

export function safetyFlagsFromAnswers(answers: Record<string, boolean>): SafetyFlag[] {
  return SAFETY_QUESTIONS.filter((q) => answers[q.id] === true).map((q) => q.flag);
}

export function excludedRisks(child: Pick<ChildProfile, 'diagnosis'>, flags: SafetyFlag[]): ExerciseRisk[] {
  const set = new Set<ExerciseRisk>(DIAGNOSIS_EXCLUSIONS[child.diagnosis]);
  for (const f of flags) FLAG_EXCLUSIONS[f].forEach((r) => set.add(r));
  return [...set];
}

export function assess(
  child: Pick<ChildProfile, 'id' | 'ageYears' | 'diagnosis'>,
  answers: Record<string, boolean>,
  now: Date = new Date(),
): FunctionalAssessment {
  const capabilities = capabilitiesFromAnswers(answers);
  const safetyFlags = safetyFlagsFromAnswers(answers);
  return {
    childId: child.id,
    date: now.toISOString(),
    answers,
    capabilities,
    level: determineLevel(capabilities, child.ageYears),
    safetyFlags,
    excludedRisks: excludedRisks(child, safetyFlags),
    clearanceRequired: safetyFlags.some((f) => CLEARANCE_FLAGS.includes(f)),
  };
}

/** Описание уровня для родителя — без медицинских терминов. */
export const LEVEL_DESCRIPTIONS: Record<FunctionalLevel, { title: string; text: string }> = {
  1: {
    title: 'Активный',
    text: 'Ребёнок уверенно ходит, поднимается по лестнице и пробует бегать. Будем развивать равновесие, скорость и координацию.',
  },
  2: {
    title: 'Ходит самостоятельно',
    text: 'Ребёнок ходит сам, но на лестнице и неровной поверхности ему нужна опора. Будем укреплять ноги и тренировать равновесие.',
  },
  3: {
    title: 'Ходит с опорой',
    text: 'Ребёнок ходит с ходунками или за руку. Будем укреплять корпус и ноги и учиться стоять увереннее.',
  },
  4: {
    title: 'Сидит',
    text: 'Ребёнок сидит сам или с небольшой поддержкой. Будем тренировать удержание корпуса, руки и переходы между положениями.',
  },
  5: {
    title: 'Нужна поддержка',
    text: 'Ребёнку нужна поддержка головы и корпуса. Будем мягко работать над контролем головы, дыханием и подвижностью суставов вместе со взрослым.',
  },
};
