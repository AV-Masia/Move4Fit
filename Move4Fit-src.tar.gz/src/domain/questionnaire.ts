import type { Capability, Diagnosis, ExerciseRisk, SafetyFlag } from './types';

/**
 * Вопросы для родителя простыми словами.
 * ⚠️ ЧЕРНОВИК: формулировки и связи с возможностями должен проверить специалист (ЛФК/реабилитолог).
 */
export interface MotorQuestion {
  id: string;
  text: string;
  hint?: string;
  capability: Capability;
  /** Вопрос задаётся, только если у ребёнка уже есть эта возможность. Иначе ответ = «нет». */
  askIf?: Capability;
}

export const MOTOR_QUESTIONS: MotorQuestion[] = [
  {
    id: 'q_head',
    text: 'Ребёнок держит голову сам, когда сидит у вас на руках?',
    capability: 'head_control',
  },
  {
    id: 'q_sit_support',
    text: 'Ребёнок может сидеть, если его немного поддерживать или посадить в кресло с опорой?',
    capability: 'sit_with_support',
    askIf: 'head_control',
  },
  {
    id: 'q_sit_free',
    text: 'Ребёнок сидит на полу или на стуле сам, не опираясь на руки, хотя бы минуту?',
    capability: 'sit_independent',
    askIf: 'sit_with_support',
  },
  {
    id: 'q_stand_support',
    text: 'Ребёнок может стоять, держась за опору (мебель, ваши руки)?',
    capability: 'stand_with_support',
    askIf: 'sit_with_support',
  },
  {
    id: 'q_stand_free',
    text: 'Ребёнок стоит сам, ни за что не держась, хотя бы несколько секунд?',
    capability: 'stand_independent',
    askIf: 'stand_with_support',
  },
  {
    id: 'q_walk_device',
    text: 'Ребёнок ходит с ходунками, тростями или держась за руку взрослого?',
    capability: 'walk_with_device',
    askIf: 'stand_with_support',
  },
  {
    id: 'q_walk_free',
    text: 'Ребёнок ходит по квартире сам, без ходунков и без вашей руки?',
    capability: 'walk_independent',
    askIf: 'stand_with_support',
  },
  {
    id: 'q_walk_outdoors',
    text: 'Ребёнок ходит сам на улице — по траве, неровной дорожке, в толпе?',
    capability: 'walk_outdoors',
    askIf: 'walk_independent',
  },
  {
    id: 'q_stairs_rail',
    text: 'Ребёнок поднимается по лестнице, держась за перила?',
    capability: 'stairs_with_rail',
    askIf: 'stand_with_support',
  },
  {
    id: 'q_stairs_free',
    text: 'Ребёнок поднимается по лестнице без перил?',
    capability: 'stairs_no_rail',
    askIf: 'walk_independent',
  },
  {
    id: 'q_run_jump',
    text: 'Ребёнок бегает и может подпрыгнуть на двух ногах?',
    capability: 'run_jump',
    askIf: 'walk_independent',
  },
];

export interface SafetyQuestion {
  id: string;
  text: string;
  flag: SafetyFlag;
}

export const SAFETY_QUESTIONS: SafetyQuestion[] = [
  { id: 's_seizures', text: 'Бывают ли у ребёнка судороги или приступы, которые сейчас не под контролем лечения?', flag: 'uncontrolled_seizures' },
  { id: 's_surgery', text: 'Была ли у ребёнка операция за последние 6 месяцев?', flag: 'recent_surgery' },
  { id: 's_botox', text: 'Делали ли ребёнку уколы ботулотоксина за последний месяц?', flag: 'recent_botulinum' },
  { id: 's_hip', text: 'Говорил ли врач о подвывихе или вывихе тазобедренного сустава?', flag: 'hip_instability' },
  { id: 's_shunt', text: 'Установлен ли у ребёнка шунт?', flag: 'shunt' },
  { id: 's_bones', text: 'Были ли переломы при небольших нагрузках или говорил ли врач о хрупкости костей?', flag: 'fragile_bones' },
  { id: 's_heart', text: 'Есть ли у ребёнка заболевание сердца, при котором ограничивают нагрузку?', flag: 'heart_condition' },
];

/**
 * ⚠️ ЧЕРНОВИК МЕДИЦИНСКОЙ ЛОГИКИ — требует проверки квалифицированным специалистом.
 * Особенности, при которых занятия показываются только после подтверждения разрешения врача.
 */
export const CLEARANCE_FLAGS: SafetyFlag[] = ['uncontrolled_seizures', 'recent_surgery', 'heart_condition'];

/** ⚠️ ЧЕРНОВИК: какие характеристики упражнений исключаются при каждой особенности. */
export const FLAG_EXCLUSIONS: Record<SafetyFlag, ExerciseRisk[]> = {
  uncontrolled_seizures: ['high_intensity', 'breath_holding', 'head_down'],
  recent_surgery: ['impact', 'hip_loading', 'high_intensity'],
  recent_botulinum: [],
  hip_instability: ['hip_loading', 'impact'],
  shunt: ['head_down', 'impact', 'neck_flexion'],
  fragile_bones: ['impact', 'hip_loading'],
  heart_condition: ['high_intensity', 'breath_holding'],
};

/** ⚠️ ЧЕРНОВИК: исключения, связанные с самим диагнозом. */
export const DIAGNOSIS_EXCLUSIONS: Record<Diagnosis, ExerciseRisk[]> = {
  cerebral_palsy: [],
  // Возможная атлантоаксиальная нестабильность — избегаем сгибания шеи и кувырков.
  down_syndrome: ['neck_flexion', 'head_down'],
  autism_spectrum: [],
  developmental_delay: [],
  spina_bifida: ['impact'],
  other: [],
};

export const DIAGNOSIS_LABELS: Record<Diagnosis, string> = {
  cerebral_palsy: 'ДЦП',
  down_syndrome: 'Синдром Дауна',
  autism_spectrum: 'Расстройство аутистического спектра',
  developmental_delay: 'Задержка моторного развития',
  spina_bifida: 'Спинномозговая грыжа',
  other: 'Другое',
};

/** Нужно ли задавать вопрос, учитывая уже данные ответы. */
export function isQuestionVisible(q: MotorQuestion, answers: Record<string, boolean>): boolean {
  if (!q.askIf) return true;
  const prerequisite = MOTOR_QUESTIONS.find((m) => m.capability === q.askIf);
  if (!prerequisite) return true;
  return answers[prerequisite.id] === true && isQuestionVisible(prerequisite, answers);
}
