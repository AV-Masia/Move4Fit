import { describe, expect, it } from 'vitest';

import { assess, determineLevel } from './functionalLevel';
import { applySessionResult } from './progression';
import { buildTodayWorkout, dayStatus, eligibleExercises, trackingTestsFor } from './selection';
import type { SessionLog } from './types';

const yes = (...ids: string[]) => Object.fromEntries(ids.map((id) => [id, true]));

describe('функциональный уровень', () => {
  it('ходит, лестница без перил, бегает → 1', () => {
    const a = assess({ id: 'c', ageYears: 7, diagnosis: 'cerebral_palsy' },
      yes('q_head', 'q_sit_support', 'q_sit_free', 'q_stand_support', 'q_stand_free', 'q_walk_free', 'q_walk_outdoors', 'q_stairs_free', 'q_run_jump'));
    expect(a.level).toBe(1);
  });

  it('ходит сам, но без бега → 2', () => {
    expect(determineLevel(['head_control', 'sit_independent', 'stand_with_support', 'walk_independent'], 8)).toBe(2);
  });

  it('ходит с ходунками → 3', () => {
    expect(determineLevel(['head_control', 'sit_independent', 'stand_with_support', 'walk_with_device'], 6)).toBe(3);
  });

  it('сидит с поддержкой → 4, не держит голову → 5', () => {
    expect(determineLevel(['head_control', 'sit_with_support'], 5)).toBe(4);
    expect(determineLevel([], 5)).toBe(5);
  });

  it('ответы на скрытые вопросы игнорируются', () => {
    // «ходит сам» отмечено, но «стоит у опоры» — нет: вопрос о ходьбе не задавался.
    const a = assess({ id: 'c', ageYears: 6, diagnosis: 'other' }, yes('q_head', 'q_sit_support', 'q_walk_free'));
    expect(a.capabilities).not.toContain('walk_independent');
    expect(a.level).toBe(4);
  });
});

describe('противопоказания', () => {
  it('нестабильность тазобедренного сустава убирает прыжки', () => {
    const a = assess({ id: 'c', ageYears: 8, diagnosis: 'cerebral_palsy' },
      yes('q_head', 'q_sit_support', 'q_sit_free', 'q_stand_support', 'q_stand_free', 'q_walk_free', 'q_walk_outdoors', 'q_stairs_free', 'q_run_jump', 's_hip'));
    expect(eligibleExercises({ ageYears: 8 }, a).map((e) => e.id)).not.toContain('two_foot_jumps');
  });

  it('операция за 6 месяцев требует разрешения врача', () => {
    const a = assess({ id: 'c', ageYears: 8, diagnosis: 'cerebral_palsy' }, yes('q_head', 's_surgery'));
    expect(a.clearanceRequired).toBe(true);
  });
});

describe('тренировка дня', () => {
  const a = assess({ id: 'c', ageYears: 6, diagnosis: 'cerebral_palsy' },
    yes('q_head', 'q_sit_support', 'q_sit_free', 'q_stand_support', 'q_walk_device'));

  it('разминка + 3 основных + заминка, всё подходит ребёнку', () => {
    const plan = buildTodayWorkout({ ageYears: 6 }, a, {}, [], new Date('2026-11-13T10:00:00Z'));
    expect(plan.items).toHaveLength(5);
    const ok = new Set(eligibleExercises({ ageYears: 6 }, a).map((e) => e.id));
    plan.items.forEach((i) => expect(ok.has(i.exerciseId)).toBe(true));
  });

  it('чередует упражнения между занятиями', () => {
    const p1 = buildTodayWorkout({ ageYears: 6 }, a, {}, []);
    const log: SessionLog = { id: '1', childId: 'c', date: '2026-11-12T10:00:00Z', items: p1.items, feedback: 'ok', pain: false };
    const p2 = buildTodayWorkout({ ageYears: 6 }, a, {}, [log]);
    expect(p2.items.map((i) => i.exerciseId)).not.toEqual(p1.items.map((i) => i.exerciseId));
  });

  it('один раз в день и цель на неделю', () => {
    const today = new Date('2026-11-13T18:00:00Z');
    const log = (d: string): SessionLog => ({ id: d, childId: 'c', date: d, items: [], feedback: 'ok', pain: false });
    expect(dayStatus([log('2026-11-13T09:00:00Z')], today).kind).toBe('done_today');
    expect(dayStatus([log('2026-11-10T09:00:00Z')], today).kind).toBe('recommended');
    expect(dayStatus([log('2026-11-08T09:00:00Z'), log('2026-11-10T09:00:00Z'), log('2026-11-11T09:00:00Z')], today).kind).toBe('rest_suggested');
  });

  it('подбирает 1–2 теста динамики', () => {
    const tests = trackingTestsFor(a);
    expect(tests.length).toBeGreaterThanOrEqual(1);
    expect(tests.length).toBeLessThanOrEqual(2);
  });
});

describe('прогрессия', () => {
  const items = [{ exerciseId: 'bridge', difficulty: 1 as const }];

  it('два раза «легко» → сложнее', () => {
    const r1 = applySessionResult({}, items, 'easy', false);
    expect(r1.progress.bridge.difficulty).toBe(1);
    const r2 = applySessionResult(r1.progress, items, 'easy', false);
    expect(r2.progress.bridge.difficulty).toBe(2);
  });

  it('«тяжело» → проще, боль → куратор', () => {
    const r = applySessionResult({ bridge: { difficulty: 3, easyStreak: 1 } }, items, 'hard', false);
    expect(r.progress.bridge.difficulty).toBe(2);
    expect(applySessionResult({}, items, 'ok', true).contactCurator).toBe(true);
  });
});
