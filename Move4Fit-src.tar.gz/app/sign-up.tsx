import { router } from 'expo-router';
import { useState } from 'react';

import { useApp } from '@/src/state/AppState';
import { Button, Field, P, Screen } from '@/src/ui/kit';

/**
 * Регистрация. Сейчас — локальная заглушка.
 * TODO: подключить серверную авторизацию (вход по email-коду), см. README.
 */
export default function SignUp() {
  const { signUp } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const valid = name.trim().length > 0 && /.+@.+\..+/.test(email.trim());

  return (
    <Screen>
      <Field label="Как вас зовут" value={name} onChangeText={setName} autoComplete="name" />
      <Field
        label="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        autoComplete="email"
      />
      <P muted>Email нужен, чтобы сохранить прогресс и связаться с куратором.</P>
      <Button
        title="Продолжить"
        disabled={!valid}
        onPress={() => {
          signUp({ name: name.trim(), email: email.trim() });
          router.replace('/child/new');
        }}
      />
    </Screen>
  );
}
