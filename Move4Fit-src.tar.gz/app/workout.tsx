import { router } from 'expo-router';
import { useState } from 'react';
import { Switch, Text, View } from 'react-native';

import { EXERCISES } from '@/src/domain/exercises';
import type { ProgressionResult } from '@/src/domain/progression';
import { buildTodayWorkout } from '@/src/domain/selection';
import type { Feedback } from '@/src/domain/types';
import { useApp } from '@/src/state/AppState';
import { ExerciseVideo } from '@/src/ui/ExerciseVideo';
import { Button, Card, Choice, H1, Notice, P, Screen, colors } from '@/src/ui/kit';

const FEEDBACK: { value: Feedback; label: string }[] = [
  { value: 'easy', label: 'Легко' },
  { value: 'ok', label: 'Нормально' },
  { value: 'hard', label: 'Тяжело' },
];

export default function Workout() {
  const { child, assessment, progress, sessions, completeSession } = useApp();
  // План фиксируем при открытии экрана, чтобы он не поменялся после сохранения.
  const [plan] = useState(() => (child && assessment ? buildTodayWorkout(child, assessment, progress, sessions) : null));
  const [step, setStep] = useState(0);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [pain, setPain] = useState(false);
  const [result, setResult] = useState<ProgressionResult | null>(null);

  if (!plan) return null;

  if (result) {
    return (
      <Screen>
        <H1>Занятие отмечено ✓</H1>
        {result.contactCurator ? (
          <Notice>
            Вы отметили боль или дискомфорт. Мы снизили нагрузку. Пожалуйста, сделайте паузу и напишите куратору, прежде
            чем продолжать.
          </Notice>
        ) : (
          <P>Спасибо! Следующее занятие подстроится под ваш отзыв.</P>
        )}
        {result.suggestReassessment && (
          <Notice>Похоже, ребёнку уже легко. Пройдите вопросы заново — возможно, пора перейти в следующую группу.</Notice>
        )}
        {result.contactCurator && <Button title="Написать куратору" onPress={() => router.replace('/(tabs)/support')} />}
        <Button title="На главную" variant={result.contactCurator ? 'secondary' : 'primary'} onPress={() => router.replace('/(tabs)')} />
      </Screen>
    );
  }

  if (step < plan.items.length) {
    const item = plan.items[step];
    const ex = EXERCISES.find((e) => e.id === item.exerciseId)!;
    const variant = ex.variants.find((v) => v.difficulty === item.difficulty) ?? ex.variants[0];
    return (
      <Screen>
        <P muted>
          Упражнение {step + 1} из {plan.items.length} · сложность {item.difficulty} из 3
        </P>
        <H1>{ex.title}</H1>
        <ExerciseVideo url={ex.videoUrl} />
        <Card>
          <P>{ex.description}</P>
          <Text style={{ fontSize: 17, fontWeight: '600', color: colors.text }}>{variant.instructions}</Text>
          {ex.equipment && <P muted>Понадобится: {ex.equipment.join(', ')}</P>}
        </Card>
        <P muted>Если ребёнку больно или он сильно устал — пропустите упражнение.</P>
        <Button title={step + 1 < plan.items.length ? 'Дальше' : 'Завершить'} onPress={() => setStep(step + 1)} />
        {step > 0 && <Button title="Назад" variant="secondary" onPress={() => setStep(step - 1)} />}
      </Screen>
    );
  }

  return (
    <Screen>
      <H1>Как прошло занятие?</H1>
      <View style={{ gap: 10 }}>
        {FEEDBACK.map((f) => (
          <Choice key={f.value} label={f.label} selected={feedback === f.value} onPress={() => setFeedback(f.value)} />
        ))}
      </View>
      <Card>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
          <P>Была боль или сильный дискомфорт</P>
          <Switch value={pain} onValueChange={setPain} />
        </View>
      </Card>
      <Button
        title="Отметить выполненным"
        disabled={!feedback}
        onPress={() => setResult(completeSession(plan, feedback!, pain))}
      />
    </Screen>
  );
}
