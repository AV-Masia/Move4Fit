import { router } from 'expo-router';
import { useState } from 'react';
import { View } from 'react-native';

import { assess } from '@/src/domain/functionalLevel';
import { MOTOR_QUESTIONS, SAFETY_QUESTIONS, isQuestionVisible } from '@/src/domain/questionnaire';
import { useApp } from '@/src/state/AppState';
import { Button, Card, H1, P, Screen } from '@/src/ui/kit';

type Q = { id: string; text: string; section: 'motor' | 'safety' };

/** Функциональное тестирование: по одному простому вопросу «да/нет». */
export default function Questionnaire() {
  const { child, saveAssessment } = useApp();
  const [answers, setAnswers] = useState<Record<string, boolean>>({});
  const [history, setHistory] = useState<string[]>([]);

  const questions: Q[] = [
    ...MOTOR_QUESTIONS.filter((q) => isQuestionVisible(q, answers)).map((q) => ({ ...q, section: 'motor' as const })),
    ...SAFETY_QUESTIONS.map((q) => ({ ...q, section: 'safety' as const })),
  ];
  const current = questions.find((q) => answers[q.id] === undefined);
  const answeredCount = questions.length - questions.filter((q) => answers[q.id] === undefined).length;

  if (!child) return null;

  const answer = (value: boolean) => {
    if (!current) return;
    setAnswers((a) => ({ ...a, [current.id]: value }));
    setHistory((h) => [...h, current.id]);
  };

  const back = () => {
    const last = history[history.length - 1];
    if (!last) return;
    setHistory((h) => h.slice(0, -1));
    setAnswers(({ [last]: _removed, ...rest }) => rest);
  };

  if (!current) {
    return (
      <Screen>
        <H1>Готово!</H1>
        <P>Спасибо. На основе ответов подберём занятия для {child.name}.</P>
        <Button
          title="Посмотреть результат"
          onPress={() => {
            saveAssessment(assess(child, answers));
            router.replace('/child/result');
          }}
        />
        <Button title="Изменить последний ответ" variant="secondary" onPress={back} />
      </Screen>
    );
  }

  return (
    <Screen>
      <P muted>
        Вопрос {answeredCount + 1} из {questions.length} ·{' '}
        {current.section === 'motor' ? 'что умеет ребёнок' : 'особенности здоровья'}
      </P>
      <Card>
        <H1>{current.text}</H1>
      </Card>
      <View style={{ gap: 12 }}>
        <Button title="Да" onPress={() => answer(true)} />
        <Button title="Нет" variant="secondary" onPress={() => answer(false)} />
        {history.length > 0 && <Button title="Назад" variant="secondary" onPress={back} />}
      </View>
      {current.section === 'motor' && (
        <P muted>Отвечайте про то, что ребёнок обычно делает сам, а не про лучший день.</P>
      )}
    </Screen>
  );
}
