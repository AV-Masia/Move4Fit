import { router } from 'expo-router';

import { LEVEL_DESCRIPTIONS } from '@/src/domain/functionalLevel';
import { useApp } from '@/src/state/AppState';
import { Button, Card, H1, Notice, P, Screen } from '@/src/ui/kit';

/** Результат: функциональный уровень простыми словами (без термина GMFCS). */
export default function Result() {
  const { child, assessment, confirmDoctorClearance } = useApp();
  if (!child || !assessment) return null;
  const level = LEVEL_DESCRIPTIONS[assessment.level];

  return (
    <Screen>
      <H1>Профиль: {child.name}</H1>
      <Card>
        <P muted>Группа занятий</P>
        <H1>{level.title}</H1>
        <P>{level.text}</P>
      </Card>
      {assessment.excludedRisks.length > 0 && (
        <Notice>С учётом ответов мы не будем предлагать некоторые упражнения (например, прыжки или наклоны вниз головой).</Notice>
      )}
      {assessment.clearanceRequired && !child.doctorClearanceConfirmed ? (
        <>
          <Notice>
            По вашим ответам перед началом занятий нужно получить разрешение лечащего врача. Покажите ему список упражнений
            или напишите куратору.
          </Notice>
          <Button title="Врач разрешил занятия" onPress={confirmDoctorClearance} />
          <Button title="Написать куратору" variant="secondary" onPress={() => router.replace('/(tabs)/support')} />
        </>
      ) : (
        <Button title="К занятиям" onPress={() => router.replace('/(tabs)')} />
      )}
      <Button title="Пройти вопросы заново" variant="secondary" onPress={() => router.replace('/child/questionnaire')} />
    </Screen>
  );
}
