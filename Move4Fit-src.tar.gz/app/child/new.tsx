import { router } from 'expo-router';
import { useState } from 'react';

import { DIAGNOSIS_LABELS } from '@/src/domain/questionnaire';
import type { Diagnosis } from '@/src/domain/types';
import { useApp } from '@/src/state/AppState';
import { Button, Choice, Field, P, Screen } from '@/src/ui/kit';

export default function NewChild() {
  const { saveChild } = useApp();
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [diagnosis, setDiagnosis] = useState<Diagnosis | null>(null);
  const [note, setNote] = useState('');
  const ageYears = Number(age.replace(',', '.'));
  const valid = name.trim() && ageYears > 0 && ageYears < 19 && diagnosis;

  return (
    <Screen>
      <Field label="Имя ребёнка" value={name} onChangeText={setName} />
      <Field label="Возраст (полных лет)" value={age} onChangeText={setAge} keyboardType="number-pad" />
      <P>Диагноз</P>
      {(Object.keys(DIAGNOSIS_LABELS) as Diagnosis[]).map((d) => (
        <Choice key={d} label={DIAGNOSIS_LABELS[d]} selected={diagnosis === d} onPress={() => setDiagnosis(d)} />
      ))}
      <Field
        label="Уточнение (необязательно): форма, сопутствующие состояния"
        value={note}
        onChangeText={setNote}
        multiline
      />
      <Button
        title="Дальше"
        disabled={!valid}
        onPress={() => {
          saveChild({ name: name.trim(), ageYears, diagnosis: diagnosis!, diagnosisNote: note.trim() || undefined });
          router.replace('/child/questionnaire');
        }}
      />
    </Screen>
  );
}
