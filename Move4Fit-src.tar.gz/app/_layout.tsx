import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';

import { AppStateProvider } from '@/src/state/AppState';

export { ErrorBoundary } from 'expo-router';

export default function RootLayout() {
  return (
    <AppStateProvider>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerBackTitle: 'Назад' }}>
        <Stack.Screen name="index" options={{ headerShown: false }} />
        <Stack.Screen name="welcome" options={{ headerShown: false }} />
        <Stack.Screen name="sign-up" options={{ title: 'Регистрация' }} />
        <Stack.Screen name="child/new" options={{ title: 'Профиль ребёнка' }} />
        <Stack.Screen name="child/questionnaire" options={{ title: 'Что умеет ребёнок' }} />
        <Stack.Screen name="child/result" options={{ title: 'Результат', headerBackVisible: false }} />
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="workout" options={{ title: 'Занятие' }} />
        <Stack.Screen name="test/[id]" options={{ title: 'Тест' }} />
      </Stack>
    </AppStateProvider>
  );
}
