import { Linking } from 'react-native';

import { SUPPORT } from '@/src/config';
import { DIAGNOSIS_LABELS } from '@/src/domain/questionnaire';
import { LEVEL_DESCRIPTIONS } from '@/src/domain/functionalLevel';
import { useApp } from '@/src/state/AppState';
import { Button, Card, H1, Notice, P, Screen } from '@/src/ui/kit';

/** Связь с куратором. В MVP — через мессенджер или почту, с кратким описанием ребёнка. */
export default function Support() {
  const { child, assessment, sessions, resetAll } = useApp();

  const summary = child
    ? `Ребёнок: ${child.name}, ${child.ageYears} лет, ${DIAGNOSIS_LABELS[child.diagnosis]}.` +
      (assessment ? ` Группа: ${LEVEL_DESCRIPTIONS[assessment.level].title}.` : '') +
      ` Занятий выполнено: ${sessions.length}.`
    : '';
  const text = encodeURIComponent(`Здравствуйте! ${summary}\n`);
  const nothingConfigured = !SUPPORT.telegram && !SUPPORT.whatsapp && !SUPPORT.email;

  return (
    <Screen>
      <H1>Куратор</H1>
      <P>Задайте вопрос о занятиях, самочувствии ребёнка или подборе упражнений.</P>
      <Notice>Если ребёнку стало плохо — звоните 103 или 112. Куратор не оказывает экстренную помощь.</Notice>
      {nothingConfigured && <P muted>Контакты куратора ещё не настроены (файл src/config.ts).</P>}
      {!!SUPPORT.telegram && (
        <Button title="Написать в Telegram" onPress={() => Linking.openURL(`https://t.me/${SUPPORT.telegram}?text=${text}`)} />
      )}
      {!!SUPPORT.whatsapp && (
        <Button title="Написать в WhatsApp" onPress={() => Linking.openURL(`https://wa.me/${SUPPORT.whatsapp}?text=${text}`)} />
      )}
      {!!SUPPORT.email && (
        <Button
          title="Написать на почту"
          variant="secondary"
          onPress={() => Linking.openURL(`mailto:${SUPPORT.email}?subject=Move4Fit&body=${text}`)}
        />
      )}
      <Card>
        <P muted>Для теста: сбросить все данные и начать заново</P>
        <Button title="Сбросить данные" variant="secondary" onPress={resetAll} />
      </Card>
    </Screen>
  );
}
