import { Tabs } from 'expo-router';
import { Text } from 'react-native';

import { colors } from '@/src/ui/kit';

const icon = (emoji: string) => () => <Text style={{ fontSize: 20 }}>{emoji}</Text>;

export default function TabsLayout() {
  return (
    <Tabs screenOptions={{ tabBarActiveTintColor: colors.primary, tabBarLabelStyle: { fontSize: 13 } }}>
      <Tabs.Screen name="index" options={{ title: 'Сегодня', tabBarIcon: icon('🏃') }} />
      <Tabs.Screen name="progress" options={{ title: 'Динамика', tabBarIcon: icon('📈') }} />
      <Tabs.Screen name="support" options={{ title: 'Куратор', tabBarIcon: icon('💬') }} />
    </Tabs>
  );
}
