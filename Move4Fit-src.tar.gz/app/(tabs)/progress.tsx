import { router } from 'expo-router';
import { Text } from 'react-native';

import { trackingTestsFor } from '@/src/domain/selection';
import { useApp } from '@/src/state/AppState';
import { Button, Card, H1, P, Screen, colors } from '@/src/ui/kit';

const fmt = (iso: string) => new Date(iso).toLocaleDateString('ru-RU');

/** Динамика: 1–2 простых теста и история занятий. */
export default function Progress() {
  const { assessment, trackingResults, sessions } = useApp();
  if (!assessment) return null;
  const tests = trackingTestsFor(assessment);

  return (
    <Screen>
      <H1>Динамика</H1>
      <P muted>Повторяйте тесты раз в 2–4 недели в одинаковых условиях.</P>
      {tests.map((t) => {
        const results = trackingResults.filter((r) => r.testId === t.id);
        return (
          <Card key={t.id}>
            <Text style={{ fontSize: 18, fontWeight: '600', color: colors.text }}>{t.title}</Text>
            {results.length === 0 ? (
              <P muted>Ещё нет результатов</P>
            ) : (
              results.slice(-5).map((r) => (
                <P key={r.id}>
                  {fmt(r.date)} — {r.value} {t.unit}
                </P>
              ))
            )}
            <Button title="Пройти тест" variant="secondary" onPress={() => router.push({ pathname: '/test/[id]', params: { id: t.id } })} />
          </Card>
        );
      })}
      <Card>
        <Text style={{ fontSize: 18, fontWeight: '600', color: colors.text }}>Занятия</Text>
        <P>Всего выполнено: {sessions.length}</P>
        {sessions.slice(-7).reverse().map((s) => (
          <P key={s.id} muted>
            {fmt(s.date)} · {s.feedback === 'easy' ? 'легко' : s.feedback === 'ok' ? 'нормально' : 'тяжело'}
            {s.pain ? ' · была боль' : ''}
          </P>
        ))}
      </Card>
    </Screen>
  );
}
