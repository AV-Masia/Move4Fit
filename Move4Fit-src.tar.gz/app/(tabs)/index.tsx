import { router } from 'expo-router';
import { useMemo } from 'react';
import { Text } from 'react-native';

import { EXERCISES } from '@/src/domain/exercises';
import { buildTodayWorkout, dayStatus } from '@/src/domain/selection';
import { useApp } from '@/src/state/AppState';
import { Button, Card, H1, Notice, P, Screen, colors } from '@/src/ui/kit';

const PART_LABEL = { warmup: 'Разминка', main: 'Основная часть', cooldown: 'Заминка' } as const;

/** «Сегодня рекомендуется выполнить эту тренировку». */
export default function Today() {
  const { child, assessment, progress, sessions } = useApp();
  const plan = useMemo(
    () => (child && assessment ? buildTodayWorkout(child, assessment, progress, sessions) : null),
    [child, assessment, progress, sessions],
  );
  if (!child || !assessment || !plan) return null;

  if (assessment.clearanceRequired && !child.doctorClearanceConfirmed) {
    return (
      <Screen>
        <Notice>Занятия откроются после того, как вы подтвердите разрешение врача.</Notice>
        <Button title="Открыть профиль" onPress={() => router.push('/child/result')} />
      </Screen>
    );
  }

  const status = dayStatus(sessions);

  return (
    <Screen>
      <H1>Привет, {child.name}!</H1>
      {status.kind === 'done_today' && <Notice>Сегодняшнее занятие уже выполнено. Отличная работа! Следующее — завтра или послезавтра.</Notice>}
      {status.kind === 'rest_suggested' && (
        <Notice>
          На этой неделе уже {status.doneThisWeek} из {status.target} занятий. Сегодня можно отдохнуть — или сделать
          занятие, если ребёнок в настроении.
        </Notice>
      )}
      {status.kind === 'recommended' && (
        <P muted>
          Сегодня рекомендуется это занятие · на неделе {status.doneThisWeek} из {status.target}
        </P>
      )}
      <Card>
        {plan.items.map((item) => {
          const ex = EXERCISES.find((e) => e.id === item.exerciseId)!;
          return (
            <Text key={item.exerciseId} style={{ fontSize: 16, color: colors.text, paddingVertical: 4 }}>
              <Text style={{ color: colors.muted }}>{PART_LABEL[ex.part]}: </Text>
              {ex.title}
            </Text>
          );
        })}
      </Card>
      {status.kind !== 'done_today' && <Button title="Начать занятие" onPress={() => router.push('/workout')} />}
    </Screen>
  );
}
